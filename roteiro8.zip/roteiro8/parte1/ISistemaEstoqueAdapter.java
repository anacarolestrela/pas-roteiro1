package roteiro8.parte1;

public interface ISistemaEstoqueAdapter 
{
    public void diminuirQuantidadeItem(); 
    public void aumentarQuantidadeItem();
} 
