package roteiro8.parte1;

public interface ISistemaContabilAdapter 
{
    void finalizarVenda(); 
    void registrarImposto();}
