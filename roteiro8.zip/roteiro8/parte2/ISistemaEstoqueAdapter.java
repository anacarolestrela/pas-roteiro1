package roteiro8.parte2;

public interface ISistemaEstoqueAdapter 
{
    public void diminuirQuantidadeItem(); 
    public void aumentarQuantidadeItem();
} 
