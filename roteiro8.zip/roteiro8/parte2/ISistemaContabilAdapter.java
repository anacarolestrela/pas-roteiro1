package roteiro8.parte2;

public interface ISistemaContabilAdapter 
{
    void finalizarVenda(); 
    void registrarImposto();}
