package roteiro4.parte1;

public interface Arma {
    public void carregar();
    public void atirar();
    public void mirar();

}
