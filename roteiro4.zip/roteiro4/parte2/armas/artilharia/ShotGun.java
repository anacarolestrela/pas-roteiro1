/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro4.parte2.armas.artilharia;

public class ShotGun {
    
    
    public void loadGun(){
        System.out.println("ShotGun carregada (Nova Arma)");
    }

    public void shotKill(){
        System.out.println("Tiro de alta destruição");
    }

    public void targetEnemy(){
        System.out.println("Mira fácil");
    }
    
}
