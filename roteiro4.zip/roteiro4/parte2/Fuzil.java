package roteiro4.parte2;

public class Fuzil implements Arma {
    @Override public void carregar()
    {
        System.out.println("Carregando Fuzil");
    }

    @Override public void atirar()
    {
        System.out.println("Esse tiro fz estrago");
    }

    @Override public void mirar()
    {
        System.out.println("Alvo certo");
    }

}
