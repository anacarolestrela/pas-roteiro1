package roteiro4.parte2;

public interface Arma {
    public void carregar();
    public void atirar();
    public void mirar();

}
