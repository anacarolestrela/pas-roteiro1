package roteiro4.parte2;

public class Rifle implements Arma{
    @Override public void carregar()
    {
        System.out.println("Carregando Rifle");
    }

    @Override public void atirar()
    {
        System.out.println("Tiro com rifle não falha");
    }

    @Override public void mirar()
    {
        System.out.println("Zoom no alvo");
    }

}
