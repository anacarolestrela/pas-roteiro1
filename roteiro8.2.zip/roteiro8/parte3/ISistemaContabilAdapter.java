package roteiro8.parte3;

public interface ISistemaContabilAdapter 
{
    void finalizarVenda(); 
    void registrarImposto();}
