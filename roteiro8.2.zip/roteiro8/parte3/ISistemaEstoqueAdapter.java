package roteiro8.parte3;

public interface ISistemaEstoqueAdapter 
{
    public void diminuirQuantidadeItem(); 
    public void aumentarQuantidadeItem();
} 
