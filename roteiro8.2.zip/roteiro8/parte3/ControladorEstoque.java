package roteiro8.parte3;

public class ControladorEstoque {
    private ISistemaEstoqueAdapter sistemaEstoqueAdapter;
    public ControladorEstoque()
    {

    }

    public void criarSistemaEstoqueAdapter(String nome)
    {
        
        if (nome.equals("IBM")) 
        this.sistemaEstoqueAdapter = new SistemaEstoqueAdapterIBM(); 
        else if (nome.equals("DELL")) 
        this.sistemaEstoqueAdapter = new SistemaEstoqueAdapterDELL();   

    }
    public void aumentarQuantidadeItem()
    { 
        this.sistemaEstoqueAdapter.aumentarQuantidadeItem(); 
    }

}
