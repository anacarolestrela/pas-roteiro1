package roteiro8.parte4;

public interface ISistemaContabilAdapter 
{
    void finalizarVenda(); 
    void registrarImposto();}
