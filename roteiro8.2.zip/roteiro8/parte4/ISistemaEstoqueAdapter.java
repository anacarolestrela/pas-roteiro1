package roteiro8.parte4;

public interface ISistemaEstoqueAdapter 
{
    public void diminuirQuantidadeItem(); 
    public void aumentarQuantidadeItem();
} 
