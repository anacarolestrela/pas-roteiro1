package roteiro8.parte5;

import roteiro8.parte5.dominio.SistemaContabil;

public class SistemaContabilAdapterIBM extends SistemaContabilAdapter
{


    public SistemaContabilAdapterIBM() 
    { 
        this.sistemacontabil = new SistemaContabil("IBM"); 
    } 
}