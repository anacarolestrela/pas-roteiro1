package roteiro8.parte5;

import roteiro8.parte1.servico.SistemaEstoque;;



public class SistemaEstoqueAdapterSAP extends SistemaEstoqueAdapter
{
    public SistemaEstoqueAdapterSAP() 
    { 
        this.sistemaEstoque = new SistemaEstoque("SAP"); 
    } 

}
