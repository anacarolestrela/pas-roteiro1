package roteiro8.parte5;

public class ControladorEstoque {
    private SistemaEstoqueAdapter sistemaEstoqueAdapter;
    public ControladorEstoque()
    {

    }

    public void criarSistemaEstoqueAdapter(String nome)
    {
        
        if (nome.equals("IBM")) 
        this.sistemaEstoqueAdapter = new SistemaEstoqueAdapterIBM(); 
        else if (nome.equals("DELL")) 
        this.sistemaEstoqueAdapter = new SistemaEstoqueAdapterDELL();   
        else if (nome.equals("SAP")) 
        this.sistemaEstoqueAdapter = new SistemaEstoqueAdapterSAP();   
        

    }
    public void aumentarQuantidadeItem()
    { 
        this.sistemaEstoqueAdapter.aumentarQuantidadeItem(); 
    }

}
