package roteiro8.parte5;

import roteiro8.parte1.servico.SistemaEstoque;;



public class SistemaEstoqueAdapterDELL extends SistemaEstoqueAdapter
{
    public SistemaEstoqueAdapterDELL() 
    { 
        this.sistemaEstoque = new SistemaEstoque("DELL"); 
    } 

}
