package roteiro8.parte5;

import roteiro8.parte5.dominio.SistemaContabil;

public class SistemaContabilAdapterDELL extends SistemaContabilAdapter
{

    public SistemaContabilAdapterDELL() 
    { 
        this.sistemacontabil = new SistemaContabil("DELL"); 
    } 
}