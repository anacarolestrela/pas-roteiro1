package roteiro8.parte5;
import roteiro8.parte5.servico.SistemaEstoque;

public abstract class SistemaEstoqueAdapter 
{
    protected roteiro8.parte1.servico.SistemaEstoque sistemaEstoque; 

    public void diminuirQuantidadeItem()
    {
        this.sistemaEstoque.removerItemEstoque();
    } 
    public void aumentarQuantidadeItem()
    {
        this.sistemaEstoque.adicionarItemEstoque();
    }
}
