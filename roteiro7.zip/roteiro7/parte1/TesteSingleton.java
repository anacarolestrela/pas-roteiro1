// package roteiro7.parte1;

// public class TesteSingleton {
//     public static void main(String[] args) {


//         System.out.println(n1 == n2? "instancias iguais":"instancias diferentes");
    
//         LazySingleton n3 =  LazySingleton.getInstance();
//         LazySingleton n4 = LazySingleton.getInstance();
//         System.out.println(n3 == n4? "instancias iguais":"instancias diferentes");

//         EargerSingleton n5 = EargerSingleton.getInstance();
//         EargerSingleton n6 = EargerSingleton.getInstance();
//         System.out.println(n5 == n6 ?"instancias iguais": "instancias diferentes");
        

//     }

// }
