package roteiro7.parte1;

public class TesteComFacade 
{ 
    public static void main(String[] args) 
    { 
        Facade n1 = Facade.getInstance();
        n1.registrarCliente("jose", 222);
        n1.comprar(1, 222); 
        n1.comprar(2, 222); 
        n1.finalizarCompra(222); 

    }
}