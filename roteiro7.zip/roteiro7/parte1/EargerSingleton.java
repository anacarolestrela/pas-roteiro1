package roteiro7.parte1;

public class EargerSingleton 
{
    private static EargerSingleton instance = new EargerSingleton();

    public EargerSingleton()
    {

    }
    public static EargerSingleton getInstance()
    {
        return instance;
    }
}
