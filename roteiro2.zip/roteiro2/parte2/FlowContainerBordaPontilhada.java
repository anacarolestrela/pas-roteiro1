package roteiro2.parte2;
import java.util.ArrayList;

import javax.lang.model.util.Elements;
import javax.swing.text.html.parser.Element;

public class FlowContainerBordaPontilhada extends Container {
    
    private ArrayList<Component> elements;

    public FlowContainerBordaPontilhada()
    {
        this.elements = new ArrayList<Component>();
    }

    @Override
    public void addComponent(Component c)
    {
        this.elements.add(c);
    }

    @Override
    public void removeComponent(Component c)
    {
        this.elements.remove(c);
    }

    @Override
    public void doLayout()
    {
        System.out.println("O Conteiner utilizado é o FlowContainer");        
        System.out.println("Este container contem bordas pontilhadas");
        System.out.println("Estes são os elemntos presentes no container");
        System.out.println(elements);
        System.out.println("Usando metodo dispose como herança para fechar o conteiner");
        this.dispose();
        System.out.println("--------------------------------");

    }


}
