package roteiro2.exemplo;

public class HydraulicGripper implements Gripper{

    @Override
    public void gerarGripper() {
        System.out.println("Garra hidraulica");
    }

}
