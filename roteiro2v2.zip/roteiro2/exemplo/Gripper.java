package roteiro2.exemplo;

public interface Gripper {
    public void gerarGripper();

}
