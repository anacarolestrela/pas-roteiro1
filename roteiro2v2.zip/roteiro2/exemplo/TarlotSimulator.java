package roteiro2.exemplo;

import java.util.ArrayList;
import java.util.List;

public class TarlotSimulator extends DroneSimulator{
            protected List<Plugins> plugin;

    public TarlotSimulator()
    {
                this.plugin =new ArrayList<Plugins>();

    }

    public TarlotSimulator(Gripper gripper)
    {
        super(gripper);
        this.plugin =new ArrayList<Plugins>();
    }

    @Override
    public void addPlugin(Plugins c) {
        this.plugin.add(c); 
    }

    @Override
    public void removePlugin(Plugins c) 
    {
        this.plugin.remove(c); 
    }

    @Override
    public void iniciarSimulacao() 
    {
        System.out.println("O Drone utilizado é o Tarlot");
        if(this.gripper!= null)
        {
            this.gripper.gerarGripper();;
        }
        System.out.println("Estes são os plugings sendo utilizados na simulação"); 
        System.out.println(plugin); 
        System.out.println("Usando o método dispose como herança para fechar o container"); 
        this.dispose(); 
        System.out.println("--------------------------------");     }

}
