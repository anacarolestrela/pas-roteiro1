package roteiro2.exemplo;

public class MagneticGripper implements Gripper{

    @Override
    public void gerarGripper() {
       System.out.println("Garra magnetica");
    }

}
