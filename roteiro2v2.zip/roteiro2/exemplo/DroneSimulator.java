package roteiro2.exemplo;

public abstract class DroneSimulator {
    protected Gripper gripper;

    public DroneSimulator()
    {

    }

    public DroneSimulator(Gripper gripper)
    {
        this.gripper= gripper;
    }

    public abstract void addPlugin (Plugins c); 
    public abstract void removePlugin (Plugins c); 
    public abstract void iniciarSimulacao(); 
    public void dispose()
    {
        System.out.println("Encerra simulação ");
    }


}
