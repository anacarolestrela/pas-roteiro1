package roteiro2.exemplo;

public class TesteSimulador {
    public static void main(String[] args) 
    {

        Plugins camera = new Plugins("Camera"); 
        Plugins lidar = new Plugins("Lidar"); 
        Plugins rangeFinder = new Plugins("RangeFiner");
        Plugins gps = new Plugins("GPS");
        Plugins barometro = new Plugins("Barometro");
        Plugins yolo = new Plugins("YoLo"); 
        Plugins orbslam = new Plugins("OrbSlam"); 
        DroneSimulator 
        c1 = new HonokyuSimulator(); 
        c1.addPlugin(camera); 
        c1.addPlugin(lidar); 
        c1.addPlugin(rangeFinder); 
        c1.addPlugin(gps); 
        c1.iniciarSimulacao(); 
        System.out.println(" ************************ "); 
        DroneSimulator 
        c2 = new TarlotSimulator(); 
        c2.addPlugin(barometro); 
        c2.addPlugin(yolo); 
        c2.addPlugin(orbslam); 
        c2.iniciarSimulacao(); 
        System.out.println(" ************************ "); 
        DroneSimulator 
        c3= new HonokyuSimulator(new HydraulicGripper());
        c3.addPlugin(orbslam); 
        c3.addPlugin(yolo); 
        c3.addPlugin(barometro); 
        c3.iniciarSimulacao(); 
        System.out.println(" ************************ "); 
        DroneSimulator 
        c4= new TarlotSimulator(new MagneticGripper());
        c4.addPlugin(orbslam); 
        c4.addPlugin(yolo); 
        c4.addPlugin(barometro); 
        c4.iniciarSimulacao();     }

}
