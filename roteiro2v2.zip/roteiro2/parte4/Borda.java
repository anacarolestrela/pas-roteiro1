 package roteiro2.parte4;

public interface Borda {
    public void gerarBorda(); 

}
