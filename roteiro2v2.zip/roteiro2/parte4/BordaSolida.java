package roteiro2.parte4;

public class BordaSolida implements Borda
{
    public void gerarBorda()
    {
        System.out.println("Borda Solida");    }

}
