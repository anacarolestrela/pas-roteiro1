package roteiro2.parte4;

public class BordaPontilhada implements Borda
{
    public void gerarBorda()
    {
        System.out.println("Borda Pontilhada");

    }

}
