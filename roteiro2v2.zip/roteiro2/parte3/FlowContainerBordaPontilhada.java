package roteiro2.parte3;
//import java.util.ArrayList;

//import javax.lang.model.util.Elements;
//import javax.swing.text.html.parser.Element;

public class FlowContainerBordaPontilhada extends FlowContainer {
    
    public FlowContainerBordaPontilhada()
    {
        super();
    }

    @Override
    public void doLayout()
    {
        System.out.println("O Conteiner utilizado é o FlowContainer");        
        System.out.println("Este container contem bordas pontilhadas");
        System.out.println("Estes são os elemntos presentes no container");
        System.out.println(super.elements);
        System.out.println("Usando metodo dispose como herança para fechar o conteiner");
        this.dispose();
        System.out.println("--------------------------------");

    }


}
